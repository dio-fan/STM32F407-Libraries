#include "led.h"
#include "stm32f4xx.h"

void LED_Init(void)
{
	gpio_init(F9, GPO, 1, GPIO_PIN_CONFIG);
	gpio_init(F10, GPO, 1, GPIO_PIN_CONFIG);
}


