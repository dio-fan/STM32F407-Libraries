#include "fan_uart.h"

const uint32_t UARTN[] = {USART1_BASE, USART2_BASE, USART3_BASE ,UART4_BASE, UART5_BASE, USART6_BASE};

#if 1
#pragma import(__use_no_semihosting)             
//��׼����Ҫ��֧�ֺ���                 
struct __FILE 
{ 
	int handle; 
}; 

FILE __stdout;       
//����_sys_exit()�Ա���ʹ�ð�����ģʽ    
int _sys_exit(int x) 
{ 
	x = x; 
} 
//�ض���fputc���� 
int fputc(int ch, FILE *f)
{ 	
	while((USART1->SR&0X40)==0);//ѭ������,ֱ���������   
	USART1->DR = (u8) ch;      
	return ch;
}
#endif

//-------------------------------------------------------------------------------------------------------------------
//  @brief      �������ų�ʼ��
//  @param      tx_pin      ���ڷ������ź�
//  @param      rx_pin      ���ڽ������ź�
//  @return     void
//  Sample usage:           �ڲ�ʹ�ã��û��������
//-------------------------------------------------------------------------------------------------------------------
void uart_gpio_init(UARTPIN_enum tx_pin, UARTPIN_enum rx_pin)
{
	if(tx_pin == UART1_TX_A9)
	{
		gpio_init(A9, AF, 0, UART_PIN_CONFIG);
		gpio_init(A10, AF, 0, UART_PIN_CONFIG);
		GPIO_PinAFConfig(GPIOA,GPIO_PinSource9,GPIO_AF_USART1); 	//GPIOA9����ΪUSART1
		GPIO_PinAFConfig(GPIOA,GPIO_PinSource10,GPIO_AF_USART1);	//GPIOA10����ΪUSART1
	}
	else if(tx_pin == UART1_TX_B6)
	{
		gpio_init(B6, AF, 0, UART_PIN_CONFIG);
		gpio_init(B7, AF, 0, UART_PIN_CONFIG);
		GPIO_PinAFConfig(GPIOB,GPIO_PinSource6,GPIO_AF_USART1);
		GPIO_PinAFConfig(GPIOB,GPIO_PinSource7,GPIO_AF_USART1);
	}
	else if(tx_pin == UART2_TX_A2)
	{
		gpio_init(A2, AF, 0, UART_PIN_CONFIG);
		gpio_init(A3, AF, 0, UART_PIN_CONFIG);
		GPIO_PinAFConfig(GPIOA,GPIO_PinSource2,GPIO_AF_USART2);
		GPIO_PinAFConfig(GPIOA,GPIO_PinSource3,GPIO_AF_USART2);
	}
	else if(tx_pin == UART2_TX_D5)
	{
		gpio_init(D5, AF, 0, UART_PIN_CONFIG);
		gpio_init(D6, AF, 0, UART_PIN_CONFIG);
		GPIO_PinAFConfig(GPIOD,GPIO_PinSource5,GPIO_AF_USART2);
		GPIO_PinAFConfig(GPIOD,GPIO_PinSource6,GPIO_AF_USART2);
	}
	else if(tx_pin == UART3_TX_B10)
	{
		gpio_init(B10, AF, 0, UART_PIN_CONFIG);
		gpio_init(B11, AF, 0, UART_PIN_CONFIG);
		GPIO_PinAFConfig(GPIOB,GPIO_PinSource10,GPIO_AF_USART3);
		GPIO_PinAFConfig(GPIOB,GPIO_PinSource11,GPIO_AF_USART3);
	}
	else if(tx_pin == UART3_TX_C10)
	{
		gpio_init(C10, AF, 0, UART_PIN_CONFIG);
		gpio_init(C11, AF, 0, UART_PIN_CONFIG);
		GPIO_PinAFConfig(GPIOC,GPIO_PinSource10,GPIO_AF_USART3);
		GPIO_PinAFConfig(GPIOC,GPIO_PinSource11,GPIO_AF_USART3);
	}
	else if(tx_pin == UART3_TX_D8)
	{
		gpio_init(D8, AF, 0, UART_PIN_CONFIG);
		gpio_init(D9, AF, 0, UART_PIN_CONFIG);
		GPIO_PinAFConfig(GPIOD,GPIO_PinSource8,GPIO_AF_USART3);
		GPIO_PinAFConfig(GPIOD,GPIO_PinSource9,GPIO_AF_USART3);
	}
	else if(tx_pin == UART4_TX_C10)
	{
		gpio_init(C10, AF, 0, UART_PIN_CONFIG);
		gpio_init(C11, AF, 0, UART_PIN_CONFIG);
		GPIO_PinAFConfig(GPIOC,GPIO_PinSource10,GPIO_AF_UART4);
		GPIO_PinAFConfig(GPIOC,GPIO_PinSource11,GPIO_AF_UART4);
	}
	else if(tx_pin == UART4_TX_A0)
	{
		gpio_init(A0, AF, 0, UART_PIN_CONFIG);
		gpio_init(A1, AF, 0, UART_PIN_CONFIG);
		GPIO_PinAFConfig(GPIOA,GPIO_PinSource0,GPIO_AF_UART4);
		GPIO_PinAFConfig(GPIOA,GPIO_PinSource1,GPIO_AF_UART4);
	}
	else if(tx_pin == UART5_TX_C12)
	{
		gpio_init(C12, AF, 0, UART_PIN_CONFIG);
		gpio_init(D2, AF, 0, UART_PIN_CONFIG);
		GPIO_PinAFConfig(GPIOC,GPIO_PinSource12,GPIO_AF_UART5);
		GPIO_PinAFConfig(GPIOD,GPIO_PinSource2,GPIO_AF_UART5);
	}
	else if(tx_pin == UART6_TX_C6)
	{
		gpio_init(C6, AF, 0, UART_PIN_CONFIG);
		gpio_init(C7, AF, 0, UART_PIN_CONFIG);
		GPIO_PinAFConfig(GPIOC,GPIO_PinSource6,GPIO_AF_USART6);
		GPIO_PinAFConfig(GPIOC,GPIO_PinSource7,GPIO_AF_USART6);
	}
	else if(tx_pin == UART6_TX_G14)
	{
		gpio_init(G14, AF, 0, UART_PIN_CONFIG);
		gpio_init(G9, AF, 0, UART_PIN_CONFIG);
		GPIO_PinAFConfig(GPIOG,GPIO_PinSource14,GPIO_AF_USART6);
		GPIO_PinAFConfig(GPIOG,GPIO_PinSource9,GPIO_AF_USART6);
	}
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      ���ڳ�ʼ��
//  @param      uartn       ����ͨ��
//  @param      baud        ������
//  @param      tx_pin      ���ڷ������ź�
//  @param      rx_pin      ���ڽ������ź�
//  @return     void
//  Sample usage:           uart_init(UART_1, 115200, UART1_TX_A9, UART1_RX_A10); //����1��ʼ�����ź�,TXΪA9,RXΪA10
//-------------------------------------------------------------------------------------------------------------------
void uart_init(UARTN_enum uartn, uint32_t baud, UARTPIN_enum tx_pin, UARTPIN_enum rx_pin)
{
	USART_InitTypeDef USART_InitStructure;
	
	//��������ʹ��
	if(UART_1 == uartn) RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	else if(UART_2 == uartn) RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	else if(UART_3 == uartn) RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
	else if(UART_4 == uartn) RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
	else if(UART_5 == uartn) RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);
	else if(UART_6 == uartn) RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART6, ENABLE);
	
	//���ų�ʼ��+����ӳ��
	uart_gpio_init(tx_pin, rx_pin);

	//���ڲ�������
	USART_InitStructure.USART_BaudRate = baud;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;

	//ʹ�ܴ���
	USART_Init((USART_TypeDef*)UARTN[uartn], &USART_InitStructure);
	USART_Cmd((USART_TypeDef*)UARTN[uartn], ENABLE);
}
