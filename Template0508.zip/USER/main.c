#include "stm32f4xx.h"
#include "led.h"
#include "delay.h"

int main(void)
{
	uint8_t key_value = 0;
	delay_init(168);
	LED_Init();
	gpio_init(E4, GPI, 1, GPIO_PIN_CONFIG);
	uart_init(UART_1, 115200, UART1_TX_A9, UART1_RX_A10);
	
	while(1){
		printf("hello world!\n");
//		key_value = GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4);
//		if(key_value)
//		{
//			GPIO_ResetBits(GPIOF,GPIO_Pin_9);
//			GPIO_ResetBits(GPIOF,GPIO_Pin_10);	
//		}
//		else
//		{
//			GPIO_SetBits(GPIOF,GPIO_Pin_9);
//			GPIO_SetBits(GPIOF,GPIO_Pin_10);
//		}

		
	  delay_ms(500);
	}
	
}
